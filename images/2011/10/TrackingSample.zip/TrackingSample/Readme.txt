http://blog.petegoo.com/index.php/2011/10/02/workflow-service-tracking-viewer/

1. Select the Service1.xamlx file in Solution Explorer
2. Press CTRL+F5 to open the WCF Test Client
3. Right Click the http://localhost:1221/Service1.xamlx or similar node in WCF Test Client and copy the address
4. Paste the address into a browser window replacing Service1.xamlx with trackingviewer
5. In WCF Test Client double click the GetData node and click Invoke to start a new instance of the workflow
6. The tracking information should appear in the browser window