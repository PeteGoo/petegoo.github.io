﻿using System;
using System.ComponentModel;

namespace MyViewModels{
public partial class Person : PersonBase {}

	public class PersonBase : INotifyPropertyChanged {


		public virtual string FirstName {
			get{ return firstname; }
			set{ 
				firstname = value; 
				NotifyPropertyChanged("FirstName");
			}
		}

		private string firstname;
		public virtual string LastName {
			get{ return lastname; }
			set{ 
				lastname = value; 
				NotifyPropertyChanged("LastName");
			}
		}

		private string lastname;
		
		public event EventHandler<PropertyChangedEventArgs> PropertyChanged;

		protected virtual void NotifyPropertyChanged(string propertyName) {
			if(PropertyChanged != null) {
				PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}
	}
public partial class Address : AddressBase {}

	public class AddressBase : INotifyPropertyChanged {


		public virtual string Line1 {
			get{ return line1; }
			set{ 
				line1 = value; 
				NotifyPropertyChanged("Line1");
			}
		}

		private string line1;
		public virtual string Line2 {
			get{ return line2; }
			set{ 
				line2 = value; 
				NotifyPropertyChanged("Line2");
			}
		}

		private string line2;
		
		public event EventHandler<PropertyChangedEventArgs> PropertyChanged;

		protected virtual void NotifyPropertyChanged(string propertyName) {
			if(PropertyChanged != null) {
				PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}
	}
}

