﻿using System.Activities;
using EightBallLibrary.Hosting;

namespace EightBallLibrary.Activities {
    public class GetWorkflowUri : CodeActivity<string> {
        protected override string Execute(CodeActivityContext context) {
            return context.GetExtension<WorkflowHostingEnvironmentExtension>().GetCurrentWorkflowUri().ToString();
        }
    }
}