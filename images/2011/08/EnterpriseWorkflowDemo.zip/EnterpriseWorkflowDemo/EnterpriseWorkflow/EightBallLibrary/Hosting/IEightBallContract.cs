using System;
using System.Collections.Generic;
using System.ServiceModel;

namespace EightBallLibrary.Hosting {
    [ServiceContract(Name = "IEightBallContract")]
    public interface IEightBallContract {
        [OperationContract]
        Guid Ask(string question, string email);
    }
}