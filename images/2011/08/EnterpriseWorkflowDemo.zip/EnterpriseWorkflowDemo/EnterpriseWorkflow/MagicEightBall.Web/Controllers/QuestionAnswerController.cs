﻿using System.Web.Mvc;
using EightBallLibrary.Activities;
using MagicEightBall.Models;
using System.ServiceModel;

namespace MagicEightBall.Controllers
{
    public class QuestionAnswerController : Controller
    {


        public ActionResult Answer(string workflowName, string questionId)
        {
            ViewBag.WorkflowName = workflowName;
            ViewBag.QuestionId = questionId;
            string question = HttpContext.Request.QueryString["Question"];
            ViewBag.Question = question;

            return View();
        }

        [HttpPost]
        public ActionResult Answer(string workflowName, string questionId, QuestionAnswerModel model) {
            ViewBag.WorkflowName = workflowName;
            ViewBag.QuestionId = questionId;
            string question = HttpContext.Request.QueryString["Question"];
            ViewBag.Question = question;

            if(ModelState.IsValid) {
                IQuestionAnswerContract answerService =
                    ChannelFactory<IQuestionAnswerContract>.CreateChannel(
                    new BasicHttpBinding(),
                    new EndpointAddress(
                        string.Format(
                            "http://localhost/HardcoreWorkflow/{0}/EightBall.svc", workflowName)));

                answerService.AnswerTheQuestion(questionId, model.Answer);
                ViewBag.Message = "Your answer has been accepted";
            }
            return View();
        }

    }
}
