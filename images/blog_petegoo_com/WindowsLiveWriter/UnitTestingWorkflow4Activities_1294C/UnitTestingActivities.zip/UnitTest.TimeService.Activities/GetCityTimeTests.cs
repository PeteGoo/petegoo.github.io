﻿using System;
using System.Activities;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PeteGoo.TimeService.Activities;

namespace UnitTest.TimeService.Activities {
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class GetCityTimeTests {
        public GetCityTimeTests() {}

        #region Test Context

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext {
            get {
                return testContextInstance;
            }
            set {
                testContextInstance = value;
            }
        }

        #endregion

        [ExpectedException(typeof(ArgumentException))]
        [TestMethod]
        public void CityIsARequiredArgument() {
            WorkflowInvoker.Invoke(new GetCityTime());
        }

        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        [TestMethod]
        public void InvalidCityThrowsArgumentException() {
            WorkflowInvoker.Invoke(new GetCityTime() {City = "BlaBlaBla"});
        }

        [TestMethod]
        public void ExecuteConvertsTimeToTargetCity() {
            DateTime currentLocalTime = DateTime.Now;
            string cityName = "London";

            TimeZoneInfo timeZoneInfo =
                TimeZoneInfo.GetSystemTimeZones().Where(
                    timeZone => timeZone.DisplayName.ToUpperInvariant().Contains(cityName.ToUpperInvariant())).First();

            DateTime result = WorkflowInvoker.Invoke(new GetCityTime() {
                                                                  City = cityName,
                                                                  LocalTime = new InArgument<DateTime>(currentLocalTime)
                                                              });
            Assert.AreEqual(TimeZoneInfo.ConvertTime(currentLocalTime, timeZoneInfo), result);
        }
    }
}
