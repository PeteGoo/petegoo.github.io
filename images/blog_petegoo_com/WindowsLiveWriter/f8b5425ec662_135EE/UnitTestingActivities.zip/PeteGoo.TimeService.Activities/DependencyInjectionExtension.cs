using System;
using System.Activities;
using System.Collections.Generic;

namespace PeteGoo.TimeService.Activities {
    public class DependencyInjectionExtension {

        private readonly Dictionary<Type, object> dependencies = new Dictionary<Type, object>();
        public void AddDependency<T>(T instance) {
            dependencies.Add(typeof(T), instance);
        }

        public T GetDependency<T>(Func<T> defaultFunc) where T : class {
            if (dependencies.ContainsKey(typeof(T))) {
                return dependencies[typeof (T)] as T;
            }

            return defaultFunc();
        }
    }

    public static class ActivityContextExtensions {
        public static T GetDependency<T>(this ActivityContext context, Func<T> defaultFunc) where T : class {
            DependencyInjectionExtension extension = context.GetExtension<DependencyInjectionExtension>();
            
            return extension == null ? defaultFunc() : extension.GetDependency<T>(defaultFunc);
            
        }
    }
}