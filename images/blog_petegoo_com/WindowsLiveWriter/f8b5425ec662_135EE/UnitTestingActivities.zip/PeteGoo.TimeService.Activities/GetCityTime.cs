using System;
using System.Activities;
using System.Linq;

namespace PeteGoo.TimeService.Activities {
    public class GetCityTime : CodeActivity<DateTime>{

        [RequiredArgument]
        public InArgument<string> City { get; set; }

        public InArgument<DateTime> LocalTime { get; set; }

        protected override DateTime Execute(CodeActivityContext context) {
            string city = City.Get(context);

            TimeZoneInfo timeZoneInfo = GetTimeZoneForCity(city);
            if (timeZoneInfo == null) {
                throw new ArgumentOutOfRangeException(string.Format("Could not find timezone matching city '{0}'", city));
            }

            return TimeZoneInfo.ConvertTime(LocalTime == null ? DateTime.Now : LocalTime.Get(context), timeZoneInfo);
        }

        private TimeZoneInfo GetTimeZoneForCity(string city) {
            return TimeZoneInfo.GetSystemTimeZones()
                .Where(
                    timezone => timezone.DisplayName.ToUpperInvariant().Contains(city.ToUpperInvariant()))
                .FirstOrDefault();

        }
    }
}