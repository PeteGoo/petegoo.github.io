using System;
using System.Activities;

namespace PeteGoo.TimeService.Activities {
    public class SendEmail : CodeActivity {
        

        #region Old constructor based dependency injection

        //private readonly IEmailClient emailClient;

        //public SendEmail() : this(new EmailClient()) {}


        //public SendEmail(IEmailClient emailClient) {
        //    this.emailClient = emailClient;
        //}

        #endregion

        public InArgument<string> To { get; set; }

        public InArgument<string> From { get; set; }

        public InArgument<string> Subject { get; set; }

        public InArgument<string> Message { get; set; }

        protected override void Execute(CodeActivityContext context) {
            IEmailClient client = context.GetDependency<IEmailClient>(() => new EmailClient());

            client.SendEmail(
                To.Get(context),
                From.Get(context),
                Subject.Get(context),
                Message.Get(context)
                );
        }
    }

    public interface IEmailClient {
        void SendEmail(string to, string from, string subject, string message);
    }

    public class EmailClient : IEmailClient {
        public void SendEmail(string to, string from, string subject, string message) {
            throw new NotImplementedException();
        }
    }
}