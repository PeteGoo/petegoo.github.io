using System;
using System.Activities.Tracking;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTest.TimeService.Activities {
    public class TestContextTrackingParticipant : TrackingParticipant {
        private readonly TestContext testContext;

        public TestContextTrackingParticipant(TestContext testContext) {
            this.testContext = testContext;
        }

        protected override void Track(TrackingRecord record, TimeSpan timeout) {
            testContext.WriteLine(string.Format("- {0}", 
                record.ToString()
                .Replace("{", "{{")
                .Replace("}", "}}")));
        }
    }
}