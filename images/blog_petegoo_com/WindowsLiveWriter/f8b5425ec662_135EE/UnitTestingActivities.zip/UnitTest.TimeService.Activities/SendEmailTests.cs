﻿using System;
using System.Activities;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PeteGoo.TimeService.Activities;

namespace UnitTest.TimeService.Activities {
    /// <summary>
    /// Summary description for SendEmailTests
    /// </summary>
    [TestClass]
    public class SendEmailTests {
        public SendEmailTests() {}

        #region Test Context

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext {
            get {
                return testContextInstance;
            }
            set {
                testContextInstance = value;
            }
        }

        #endregion

        [TestMethod]
        public void ExecuteCallsSendEmailOnClient() {
            StubEmailClient stubEmailClient = new StubEmailClient();

            WorkflowInvoker invoker = new WorkflowInvoker(
                new SendEmail {
                                               From = "foo@foo.com",
                                               To = "bar@bar.com",
                                               Subject = "The Subject",
                                               Message = "The Message"
                                           
                });

            DependencyInjectionExtension dependencyInjectionExtension = new DependencyInjectionExtension();
            dependencyInjectionExtension.AddDependency<IEmailClient>(stubEmailClient);

            invoker.Extensions.Add(dependencyInjectionExtension);

            invoker.Invoke();

            Assert.AreEqual(1, stubEmailClient.SentEmails);
        }

        private class StubEmailClient : IEmailClient {
            private int sentEmails;
            public int SentEmails {
                get { return sentEmails; }
            }
            public void SendEmail(string to, string from, string subject, string message) {
                sentEmails++;
            }
        }
    }

    
}
