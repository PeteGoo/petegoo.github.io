﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace WcfService1 {
    public class Service1 : IService1 {
        public string Start(int value) {
            return string.Format("Calculation session started with value {0}", value);
        }
    }

    [ServiceContract]
    public interface IService1 {

        [OperationContract]
        string Start(int value);
    }
}
