﻿using System;

namespace ApproverClient {
    class Program {
        static void Main(string[] args) {
            Console.Write("Starting Workflow...");
            ApprovalWorkflowService.ServiceClient client = new ApprovalWorkflowService.ServiceClient();
            client.BeginApprovalProcess(new[] {
                                                  "approver1@domain.com", 
                                                  "approver2@domain.com", 
                                                  "approver3@domain.com"
                                              },
                                              "Am I the best?",
                                              "teched2010@domain.com");
           
            
            Console.WriteLine("Started");
            Console.ReadKey(false);
        }
    }
}
