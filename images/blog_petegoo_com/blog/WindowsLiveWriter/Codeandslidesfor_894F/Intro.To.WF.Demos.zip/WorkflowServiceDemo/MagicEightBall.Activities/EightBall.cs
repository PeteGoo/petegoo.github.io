using System;
using System.Activities;

namespace MagicEightBall.Activities {
    public class EightBall : CodeActivity<string> {

        public static readonly string[] Answers = {   "Yes", 
                                                      "No", 
                                                      "Ask again", 
                                                      "Definitely",
                                                      "That would be an ecumenical matter",
                                                      "Bad idea", 
                                                      "Perhaps", 
                                                      "Unsure" };

        public InArgument<string> Question { get; set; }

        protected override string Execute(CodeActivityContext context) {
            return Answers[Question.Get(context).Length % Answers.Length];
        }
    }
}