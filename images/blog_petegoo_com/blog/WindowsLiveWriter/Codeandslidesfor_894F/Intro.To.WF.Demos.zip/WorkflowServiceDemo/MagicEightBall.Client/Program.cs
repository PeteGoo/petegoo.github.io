﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Activities;
using System.Activities.Statements;

namespace MagicEightBall.Client {

    class Program {
        static void Main(string[] args) {
            Console.WriteLine("Please ask a question");
            string question = Console.ReadLine();

            WorkflowInvoker.Invoke(new Workflow1(), new Dictionary<string, object>(){{"Question", question}});
        }
    }
}
