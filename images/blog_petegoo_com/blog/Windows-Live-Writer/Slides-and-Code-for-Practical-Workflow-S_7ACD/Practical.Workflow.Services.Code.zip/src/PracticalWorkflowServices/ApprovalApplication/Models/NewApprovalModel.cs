using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace ApprovalApplication.Models {
    public class NewApprovalModel {
        [Required]
        [DisplayName("Requestor Email Address")]
        [DataType(DataType.EmailAddress)]
        public string RequestorAddress { get; set; }

        [Required]
        [DisplayName("Message to approve")]
        [DataType(DataType.MultilineText)]
        public string Message { get; set; }

        [Required]
        [DisplayName("Requestor Email Address")]
        [DataType(DataType.MultilineText)]
        public string Approvers { get; set; }

    }
}