using System;
using System.Activities;
using System.Activities.Tracking;

namespace ApprovalService {
    public class Log : CodeActivity {
        [RequiredArgument]
        public InArgument<string> Message { get; set; }

        protected override void Execute(CodeActivityContext context) {
            CustomTrackingRecord trackingRecord = new CustomTrackingRecord("Log");
            trackingRecord.Data.Add("Message", Message.Get(context));
            context.Track(trackingRecord);
        }
    }
}