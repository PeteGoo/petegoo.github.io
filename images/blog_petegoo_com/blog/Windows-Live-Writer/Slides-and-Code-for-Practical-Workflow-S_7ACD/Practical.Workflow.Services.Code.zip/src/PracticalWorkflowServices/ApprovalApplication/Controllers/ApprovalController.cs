using System;
using System.Web.Mvc;
using ApprovalApplication.ApprovalWorkflowService;
using ApprovalApplication.Models;

namespace ApprovalApplication.Controllers {
    public class ApprovalController : Controller {
        public ActionResult NewApprovalRequest() {
            return View();
        }

        [HttpPost]
        public ActionResult NewApprovalRequest(NewApprovalModel approvalRequestModel) {
            if (this.ModelState.IsValid) {
                
                //TODO: Insert code to initiate workflow
                ApprovalServiceClient client = new ApprovalServiceClient();
                client.RequestApproval(
                    approvalRequestModel.RequestorAddress,
                    approvalRequestModel.Message,
                    approvalRequestModel.Approvers.Trim().Split(new[]{Environment.NewLine}, StringSplitOptions.RemoveEmptyEntries)
                    );
                ViewData["Message"] = "Approval Sent";
            }
            return View();
        }

        
        public ActionResult Approve(string id) {

            //TODO: Insert code to call Approve on workflow service
            ApprovalServiceClient client = new ApprovalServiceClient();
            client.Approve(id);
            return View();
        }

        public ActionResult Decline(string id) {

            //TODO: Insert code to call Decline on workflow service
            ApprovalServiceClient client = new ApprovalServiceClient();
            client.Decline(id);
            return View();
        }
    }
}